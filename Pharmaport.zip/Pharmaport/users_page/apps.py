from django.apps import AppConfig


class UsersPageConfig(AppConfig):
    name = 'users_page'
