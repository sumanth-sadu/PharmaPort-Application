from django.contrib import admin
from Doctors.models import prescription,apointment_1,Profile

admin.site.register(prescription)
admin.site.register(apointment_1)
admin.site.register(Profile)



# Register your models here.
