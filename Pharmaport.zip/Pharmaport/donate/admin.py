from django.contrib import admin

# Register your models here.
from donate.models import don_sub


admin.site.register(don_sub)