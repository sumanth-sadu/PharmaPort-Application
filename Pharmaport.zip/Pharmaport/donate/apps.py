from django.apps import AppConfig


class DonateConfig(AppConfig):
    name = 'donate'
