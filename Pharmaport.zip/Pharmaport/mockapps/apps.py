from django.apps import AppConfig


class MockappsConfig(AppConfig):
    name = 'mockapps'
